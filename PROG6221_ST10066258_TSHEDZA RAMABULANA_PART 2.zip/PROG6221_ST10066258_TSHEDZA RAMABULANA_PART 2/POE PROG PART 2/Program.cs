﻿using NUnit.Framework;
using System;
using System.Collections.Generic;

class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> Steps { get; set; }

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<string>();
    }

    public double CalculateTotalCalories()
    {
        double totalCalories = 0;
        foreach (Ingredient ingredient in Ingredients)
        {
            totalCalories += ingredient.Calories;
        }
        return totalCalories;
    }
}

class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public double Calories { get; set; }
    public string FoodGroup { get; set; }
}

class RecipeApplication
{
    private static List<Recipe> recipes = new List<Recipe>(); // List to store the recipes

    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        Console.WriteLine("|        Welcome to the Recipe Application        |");
        Console.WriteLine("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        Console.ResetColor();

        bool quit = false;
        while (!quit)
        {
            Console.WriteLine("Please select one of the following options!");
            Console.WriteLine("1. Enter a new recipe");
            Console.WriteLine("2. Scale a recipe");
            Console.WriteLine("3. Reset a recipe");
            Console.WriteLine("4. Clear all data");
            Console.WriteLine("5. Display all recipes");
            Console.WriteLine("6. Quit");

            string input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    EnterRecipe();
                    break;
                case "2":
                    ScaleRecipe();
                    break;
                case "3":
                    ResetRecipe();
                    break;
                case "4":
                    ClearData();
                    break;
                case "5":
                    DisplayAllRecipes();
                    break;
                case "6":
                    quit = true;
                    break;
                default:
                    Console.WriteLine("Invalid input, please try again");
                    break;
            }
        }
    }

    static void EnterRecipe()
    {
        Console.WriteLine("Enter the name of the recipe:");
        string recipeName = Console.ReadLine();

        Recipe recipe = new Recipe(recipeName);

        Console.WriteLine("Enter the number of ingredients:");
        int ingredientCount = int.Parse(Console.ReadLine());

        for (int i = 0; i < ingredientCount; i++)
        {
            Console.WriteLine($"Ingredient #{i + 1}");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit: ");
            string unit = Console.ReadLine();
            Console.Write("Calories: ");
            double calories = double.Parse(Console.ReadLine());
            Console.Write("Food Group: ");
            string foodGroup = Console.ReadLine();

            Ingredient ingredient = new Ingredient
            {
                Name = name,
                Quantity = quantity,
                Unit = unit,
                Calories = calories,
                FoodGroup = foodGroup
            };

            recipe.Ingredients.Add(ingredient);
        }

        Console.WriteLine("Enter the number of steps:");
        int stepCount = int.Parse(Console.ReadLine());

        for (int i = 0; i < stepCount; i++)
        {
            Console.WriteLine($"Step #{i + 1}:");
            string step = Console.ReadLine();
            recipe.Steps.Add(step);
        }

        recipes.Add(recipe);

        Console.WriteLine("Recipe added successfully!");
    }

    static void DisplayAllRecipes()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("No recipes found.");
            return;
        }

        Console.WriteLine("List of Recipes:");
        List<Recipe> sortedRecipes = new List<Recipe>(recipes);
        sortedRecipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));

        int recipeNumber = 1;
        foreach (Recipe recipe in sortedRecipes)
        {
            Console.WriteLine($"{recipeNumber}. {recipe.Name}");
            recipeNumber++;
        }

        Console.WriteLine("Enter the recipe number to display the details (or '0' to go back):");
        int recipeIndex = int.Parse(Console.ReadLine()) - 1;

        if (recipeIndex >= 0 && recipeIndex < recipes.Count)
        {
            DisplayRecipeDetails(recipes[recipeIndex]);
        }
    }

    static void DisplayRecipeDetails(Recipe recipe)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"\nRecipe: {recipe.Name}");
        Console.ResetColor();

        Console.WriteLine("\nIngredients:");
        foreach (Ingredient ingredient in recipe.Ingredients)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} {ingredient.Name}");
            Console.ResetColor();
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < recipe.Steps.Count; i++)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"{i + 1}. {recipe.Steps[i]}");
            Console.ResetColor();
        }

        double totalCalories = recipe.CalculateTotalCalories();
        Console.WriteLine($"\nTotal Calories: {totalCalories}");

        if (totalCalories > 300)
        {
            Console.WriteLine("Warning: This recipe exceeds 300 calories!");
        }
    }

    static void ScaleRecipe()
    {
        Console.WriteLine("Enter the name of the recipe to scale:");
        string recipeName = Console.ReadLine();

        Recipe recipe = FindRecipeByName(recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }

        Console.WriteLine("Enter the scaling factor (0.5, 2, or 3):");
        double factor = double.Parse(Console.ReadLine());

        foreach (Ingredient ingredient in recipe.Ingredients)
        {
            ingredient.Quantity *= factor;
        }

        Console.WriteLine("Recipe scaled successfully!");
        DisplayRecipeDetails(recipe);
    }

    static void ResetRecipe()
    {
        Console.WriteLine("Enter the name of the recipe to reset:");
        string recipeName = Console.ReadLine();

        Recipe recipe = FindRecipeByName(recipeName);
        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
            return;
        }

        DisplayRecipeDetails(recipe);
    }

    static void ClearData()
    {
        Console.WriteLine("Are you sure you want to clear all data? (Y/N)");
        string userInput = Console.ReadLine().ToUpper();

        if (userInput == "Y" || userInput == "YES")
        {
            recipes.Clear();
            Console.WriteLine("Data cleared.");
        }
        else
        {
            Console.WriteLine("Data not cleared.");
        }
    }

    static Recipe FindRecipeByName(string recipeName)
    {
        return recipes.Find(recipe => recipe.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
    }
}

class RecipeApplication1
{
    // Existing code for the RecipeApplication class

    // ...
}

// Unit test code
[TestFixture]
public class RecipeTests
{
    [Test]
    public void CalculateTotalCalories_ShouldReturnCorrectTotalCalories()
    {
        // Arrange
        Recipe recipe = new Recipe("Test Recipe");
        recipe.Ingredients = new List<Ingredient>
        {
            new Ingredient { Name = "Ingredient 1", Quantity = 1, Unit = "unit", Calories = 100 },
            new Ingredient { Name = "Ingredient 2", Quantity = 2, Unit = "unit", Calories = 50 },
            new Ingredient { Name = "Ingredient 3", Quantity = 3, Unit = "unit", Calories = 75 }
        };

        double expectedTotalCalories = 100 + 2 * 50 + 3 * 75;

        // Act
        double actualTotalCalories = recipe.CalculateTotalCalories();

        // Assert
        Assert.AreEqual(expectedTotalCalories, actualTotalCalories);
    }
}